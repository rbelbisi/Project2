// Query 3:This query uses the aggregation framework to count the number of documents in the Admin collection where the email field ends with @marriott.com. The $match stage filters the documents, and the $count stage counts the number of matching documents and labels the count as marriott_email_count.

db.getCollection('admin').aggregate(
  [
    {
      $match: {
        email: { $regex: '@marriott.com$' }
      }
    },
    { $count: 'marriott_email_count' }
  ],
  { maxTimeMS: 60000, allowDiskUse: true }
);