// Query 5: Filtering and Sorting
db.Station.find({ dock_count: { $gte: 20 } }).sort({ installation_date: 1 });
