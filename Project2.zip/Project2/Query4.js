  // Query 4: Updating a Document
  db.getCollection('users').aggregate(
  [
    { $match: { first_name: 'Gus' } },
    { $set: { trips: 4 } }
  ],
  { maxTimeMS: 60000, allowDiskUse: true }
);