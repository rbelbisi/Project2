// Query 2: This query will return all documents in the Users collection where the user is female and the phone number starts with "123".
db.getCollection('users').find({
    $and: [
      { gender: 'Female' },
      { phone_number: { $regex: '^123' } }
    ]
  });