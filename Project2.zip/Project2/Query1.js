// Query 1: Aggregation
// This query counts the number of stations in each city.
db.getCollection('stations').aggregate(
  [
    {
      $group: { _id: '$city', count: { $sum: 1 } }
    }
  ],
  { maxTimeMS: 60000, allowDiskUse: true }
);
